<?php
$server="localhost";
$username="id6278498_todolist";
$password="todolist";
$db="id6278498_todolist"
?>